import { useState } from "react";
import { supabase } from "../utils/supabaseClient";

export default function Unban() {
  const [reason, setReason] = useState("");

  const submitRequest = async () => {
    const user = supabase.auth.getUser();
    if (!user) return alert("Not logged in");

    const { error } = await supabase.from("unban_requests").insert({ reason });
    if (error) alert(error.message);
    else alert("Request submitted");
  };

  return (
    <div className="p-4 text-white">
      <h2 className="text-2xl mb-2">Unban Request</h2>
      <textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Why should we unban you?" className="block w-full mb-4 p-2 text-black" />
      <button onClick={submitRequest} className="bg-yellow-600 px-4 py-2 rounded">Submit</button>
    </div>
  );
}