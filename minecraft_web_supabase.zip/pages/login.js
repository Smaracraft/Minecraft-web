import { useState } from "react";
import { supabase } from "../utils/supabaseClient";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async () => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) alert(error.message);
    else alert("Login successful");
  };

  return (
    <div className="p-4 text-white">
      <h2 className="text-2xl mb-2">Login</h2>
      <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="block mb-2 p-2 text-black" />
      <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" type="password" className="block mb-4 p-2 text-black" />
      <button onClick={handleLogin} className="bg-green-600 px-4 py-2 rounded">Login</button>
    </div>
  );
}