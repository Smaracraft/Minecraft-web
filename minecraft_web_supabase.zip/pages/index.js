export default function Home() {
  return (
    <main className="p-6 text-center text-white">
      <h1 className="text-3xl font-bold mb-4">Minecraft Server Login</h1>
      <p>Login or register to submit an Unban request.</p>
    </main>
  );
}